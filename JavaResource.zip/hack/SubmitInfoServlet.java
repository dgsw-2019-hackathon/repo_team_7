package dgsw.java.class2.hack;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dgsw.java.class2.hack.service.Hackathon;
import dgsw.java.class2.hack.service.HackathonImpl;
import dgsw.java.class2.hack.service.Info;

/**
 * 양식 제출 서블릿
 */
@WebServlet("/Hack/submitInfo.do")
public class SubmitInfoServlet extends HttpServlet {
	
	Hackathon service = new HackathonImpl();
	
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		
		String userId = request.getParameter("userId");
		String address = request.getParameter("address");
		String age = request.getParameter("age");
		String infor = request.getParameter("infor");
		String disease = request.getParameter("disease");
		String family = request.getParameter("family");
		int iAge = Integer.parseInt(age);
		int iUserId = Integer.parseInt(userId);
		
		Info info = new Info();
		
		info.setAddress(address);
		info.setAge(iAge);
		info.setInfor(infor);
		info.setDisease(disease);
		info.setFamily(family);
		info.setUserId(iUserId);
		
		try {
			service.updateInfo(info);
			
			response.getWriter().append("UPDATEINFO_SUCCESS");
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
			response.getWriter().append("UPDATEINFO_FAIL");
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}

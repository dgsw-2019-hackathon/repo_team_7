package dgsw.java.class2.hack;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.bcel.internal.generic.INSTANCEOF;

/**
 * Servlet implementation class SerialServlet
 */
@WebServlet("/Hack/serial.do")
public class SerialServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
       
   SerialTrans main;
   String result;
   /**
    * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
    */
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      String check = request.getParameter("check");
      
      if("true".equals(check))
      {
         System.out.println("check");
         main = new SerialTrans();
         main.initialize();
         System.out.println("Started");
      }
      
      result = "";
      if(main.getData() != null)
      {
         if(main.getData().indexOf("1") == -1)
         {
            result = "0";
         }
         else
         {
            result = "1";
         }
      }
      
      if("1".equals(result))
      {
         System.out.println("if " + main.data); 
         result = "true";
      }
      else
      {
         System.out.println("else " + main.data);
         result = "false";
      }
      response.getWriter().append(result);
   }

   /**
    * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
    */
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      
   }
}


package dgsw.java.class2.hack.service;

public interface Hackathon {
	
	/** 회원가입
	 * @param user 유저의 정보
	 */
	public void register(HackUser user);
	
	/** 로그인
	 * @param userId 로그인 할 유저의 아이디
	 * @return 로그인의 성공 여부
	 */
	public boolean login(String userId, String pw);
	
	/** id를 입력받아 유저 정보 반환
	 * @param userId
	 * @return
	 */
	public HackUser getUser(String userId);
	
	public HackUser getUserByKey(String userKey);
	
	public void updateInfo(Info info);
	
	public Info getInfoByUserKey(int userId);
	
	public Sensing getSensingBySensId(int sensId);
	
	public void updateSensing(Sensing sensing);
	
	public void clearSensing();
}

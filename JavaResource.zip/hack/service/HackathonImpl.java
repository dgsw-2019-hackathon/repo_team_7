package dgsw.java.class2.hack.service;

import java.sql.ResultSet;

import dgsw.java.class2.JdbcDoer;

public class HackathonImpl implements Hackathon {

	JdbcDoer jdbcDoer = new JdbcDoer();
	
	@Override
	public void register(HackUser user) {

		StringBuilder sql = new StringBuilder();

		sql.append("INSERT INTO hack_user (id, pw, name)	");
		sql.append("VALUES (?, ?, ?);	");

		try {

			jdbcDoer.update(sql.toString(), user.getId(), user.getPw(), user.getName());
		}

		catch (Exception e) {

			e.printStackTrace();
		}
	}

	@Override
	public boolean login(String userId, String pw) {
		
		HackUser user = getUser(userId); //유저의 정보를 가지고 와서
		
		//아이디와 비밀번호가 DB와 같다면 true 반환
		if(user.getId().equals(userId) && user.getPw().equals(pw)) {
			
			return true;
		}
		
		else {
			
			return false;
		}
	}

	@Override
	public HackUser getUser(String userId) {
	
		HackUser user = null;
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM hack_user	");
		sql.append("WHERE id = ?	");
		
		try {
			
			ResultSet rs = jdbcDoer.query(sql.toString(), userId);
			
			if(rs.next()) {
				
				String tableId = rs.getString("id");
				String tablePw = rs.getString("pw");
				int tableUserId = rs.getInt("user_id");
				String name = rs.getString("name");
				
				user = new HackUser();
				
				user.setId(tableId);
				user.setPw(tablePw);
				user.setUserId(tableUserId);
				user.setName(name);
			}
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}

	@Override
	public HackUser getUserByKey(String userKey) {
		
		int numUserKey = Integer.parseInt(userKey);
		
		HackUser user = null;
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM hack_user	");
		sql.append("WHERE user_id = ?;	");
		
		try {
			
			ResultSet rs = jdbcDoer.query(sql.toString(), numUserKey);
			
			if(rs.next()) {
				
				int userId = rs.getInt("user_id");
				String id = rs.getString("id");
				String pw = rs.getString("pw");
				String name = rs.getString("name");
				
				user = new HackUser();
				
				user.setUserId(userId);
				user.setId(id);
				user.setPw(pw);
				user.setName(name);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}

	@Override
	public void updateInfo(Info info) {
		
		StringBuilder sql = new StringBuilder();

		sql.append("INSERT INTO writeinfo (user_id, address, age, infor, disease , family)	");
		sql.append("VALUES (?, ?, ?, ?, ?, ?);	");

		try {

			jdbcDoer.update(sql.toString(), info.getUserId(), info.getAddress(), info.getAge(), info.getInfor(), info.getDisease(), info.getFamily());
		}

		catch (Exception e) {

			e.printStackTrace();
		}
	}

	@Override
	public Info getInfoByUserKey(int userId) {
		
		Info info = null;
		
		StringBuilder sql = new StringBuilder();

		sql.append("SELECT * FROM writeinfo,hack_user	");
		sql.append("WHERE writeinfo.user_id = hack_user.user_id AND writeinfo.user_id = ?	");

		try {

			ResultSet rs = jdbcDoer.query(sql.toString(), userId);
			
			if(rs.next()) {
				
				int infoId = rs.getInt("info_id");
				String address = rs.getString("address");
				int age = rs.getInt("age");
				String infor = rs.getString("infor");
				String disease = rs.getString("disease");
				String family = rs.getString("family");
				
				info = new Info();
				
				info.setInfoId(infoId);
				info.setAddress(address);
				info.setAge(age);
				info.setDisease(disease);
				info.setFamily(family);
				info.setInfor(infor);
			}
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		
		return info;
	}

	@Override
	public Sensing getSensingBySensId(int sensId) {
		
		Sensing sensing = null;
		
		StringBuilder sql = new StringBuilder();

		sql.append("SELECT * FROM sensing	");
		sql.append("WHERE sens_id = ?	");

		try {

			ResultSet rs = jdbcDoer.query(sql.toString(), sensId);
			
			if(rs.next()) {
				
				int tableSensId = rs.getInt("sens_id");
				String tableResult = rs.getString("result");

				sensing = new Sensing();
				
				sensing.setSensId(tableSensId);
				sensing.setResult(tableResult);
			}
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		
		return sensing;
	}

	@Override
	public void updateSensing(Sensing sensing) {
		
		StringBuilder sql = new StringBuilder();

		sql.append("INSERT INTO sensing (sens_id, result)	");
		sql.append("VALUES (?, ?);	");

		try {

			jdbcDoer.update(sql.toString(), sensing.getSensId(), sensing.getResult());
		}

		catch (Exception e) {

			e.printStackTrace();
		}
	}

	@Override
	public void clearSensing() {
		
		StringBuilder sql = new StringBuilder();

		sql.append("DELETE FROM sensing	");

		try {

			jdbcDoer.update(sql.toString());
		}

		catch (Exception e) {

			e.printStackTrace();
		}
	}
}

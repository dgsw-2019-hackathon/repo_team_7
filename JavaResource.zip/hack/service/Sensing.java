package dgsw.java.class2.hack.service;

public class Sensing {

	private int sensId = 0;
	private String result = null;
	
	public int getSensId() {
		return sensId;
	}
	public void setSensId(int sensId) {
		this.sensId = sensId;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
}

package dgsw.java.class2.hack;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dgsw.java.class2.hack.service.HackUser;
import dgsw.java.class2.hack.service.Hackathon;
import dgsw.java.class2.hack.service.HackathonImpl;

/**
 * 회원가입 서블릿
 */
@WebServlet("/Hack/regist.do")
public class RegisterDo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		
		String result = null;
		
		Hackathon service = new HackathonImpl();
		
		HackUser user = new HackUser();
		
		user.setId(request.getParameter("id"));
		user.setPw(request.getParameter("pw"));
		user.setName(request.getParameter("name"));
		
		System.out.println(request.getParameter("name"));
		
		try {
			
			service.register(user);
			result = "REGISTER_SUCCESS";
		}
		
		catch(Exception e) {
			
			e.printStackTrace();
			result = "REGISTER_FAIL";
		}
		
		System.out.println("REGISTER:" + result);
		response.getWriter().append(result);
	}
}

$("form").on("subimit", function() {
	
	console.log("onsubmit");
});
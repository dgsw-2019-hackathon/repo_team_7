var second = 0; //초
var mode = false;
var check = "true";

window.onload = function() {
	
	console.log(mode);
	
	//1초가 지날 때마다 초를 센다.
	
}

function timing() {
	
	//10초를 지나면
	if(second >= 10) {
		
		document.querySelector(".caution").style.backgroundColor = "#F26157";
	}
	
	else {
		
		document.querySelector(".caution").style.backgroundColor = "#FCAB10";
	}
	
	second ++; 

	console.log(second);
	
	document.getElementById("time").innerHTML = second;
}


